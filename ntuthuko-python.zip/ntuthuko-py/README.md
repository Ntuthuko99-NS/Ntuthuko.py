# Ntuthuko time clock (Python / Flask)

Python port of the React app: employees, shifts, leave, timesheets, reports,
alerts, WhatsApp settings and a clock in/out widget.

## Run

```bash
pip install -r requirements.txt
python run.py            # http://127.0.0.1:5000
python -m unittest discover -s tests
```

Environment variables (all optional): `NTUTHUKO_DATA` (data file, default
`ntuthuko_data.json`), `SECRET_KEY`, `APP_TZ` (e.g. `Africa/Johannesburg`;
default is the server's timezone), `HOST`, `PORT`, `FLASK_DEBUG=1`.

## Where things went

| React                                   | Python                                          |
| --------------------------------------- | ----------------------------------------------- |
| `App.jsx` routes, `Layout.js`           | `ntuthuko/__init__.py`, `pages.py`, `templates/base.html` |
| `pages/*.jsx`                           | route functions in `pages.py` + `templates/<page>.html` |
| `components/*.jsx`, `ui.jsx`            | Jinja macros in `templates/components.html`, `_ui.html`; helpers in `ui.py` |
| `api/ntuthukoClient.js`, `useEntity.js` | `client.py` (same `list/filter/create/update/delete` shape, JSON file instead of localStorage) |
| `services/AlertService.js`              | `services/alerts.py`                            |
| `components/ClockOfflineSync.js`        | `clock.py`                                      |
| `entities/*.json`                       | `models.py` (dataclasses)                       |

## Before exposing it beyond your own machine

- There is no login: `client.auth.me()` returns a demo admin (or whatever is
  stored under the `me` key). Add real authentication.
- Forms have no CSRF protection (e.g. add Flask-WTF).
- Set a real `SECRET_KEY`.
- Tailwind is loaded from its CDN; build it with the Tailwind CLI for production.
- Sending WhatsApp messages needs the WhatsApp Business Cloud API on a server.
